package genericLibraries;
/**
 * This interface contains all the external file paths
 * @author Srivalli
 */
public interface IConstantPath {

	String PROPERTIES_PATH = "./src/test/resources/commonData.properties";
	String EXCEL_PATH = "./src/test/resources/SkillRaryTestData.xlsx";
}
